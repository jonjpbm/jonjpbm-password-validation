"""
pyPasswordValidator.
Password validator
"""

__version__ = "0.1.0"
__author__ = 'Jon Duarte'
__credits__ = 'iHeart Media'
